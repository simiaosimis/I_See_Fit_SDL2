todo sdl2-engine readme
